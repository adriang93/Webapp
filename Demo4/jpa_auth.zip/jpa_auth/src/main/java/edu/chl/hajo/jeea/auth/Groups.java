
package edu.chl.hajo.jeea.auth;

/**
 * Categories of users
 * @author hajo
 */
public enum Groups {
    USER,
    ADMIN,
   // POWERUSER,
 
}
