package edu.chl.hajo.ejbsb.iface;

import javax.ejb.Stateless;

/**
 * Possible to have interface to EJB
 * @author hajo
 */
@Stateless
public class StatelessWIfaceSB implements IStatelessWIfaceSB {

   
    
}
