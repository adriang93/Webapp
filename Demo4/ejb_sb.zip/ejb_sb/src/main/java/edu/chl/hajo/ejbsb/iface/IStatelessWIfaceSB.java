
package edu.chl.hajo.ejbsb.iface;

import javax.ejb.Local;

/**
 *
 * @author hajo
 */
@Local  // Local interface
public interface IStatelessWIfaceSB {
    
}
